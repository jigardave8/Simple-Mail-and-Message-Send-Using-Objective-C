//
//  ViewController.m
//  MailAndMessageSending
//
//  Created by mac on 6/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setBtnSentMessage:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)btnSentMessage:(id)sender {
    
    
    messageComposer =[[MFMessageComposeViewController alloc]init];
    [messageComposer setBody:@"Hi wel come"];
    [messageComposer setRecipients:[NSArray arrayWithObjects:@"4567897895", nil]];
    if(messageComposer !=nil)
    {
        [self presentModalViewController:messageComposer animated:YES];
    }
    [messageComposer release];
}

- (IBAction)btnSentMail:(id)sender {
    
    
    
    mailComposer =[[MFMailComposeViewController alloc]init];
     
    [mailComposer setToRecipients:[NSArray arrayWithObjects:@"abc@gmail.com", nil]];
    [mailComposer setCcRecipients:[NSArray arrayWithObjects:@"abc@gmail.com", nil]];
    [mailComposer setMessageBody:@"this is my mail<p>this</p>" isHTML:YES];
    [mailComposer setSubject:@"test mailCom"];
    if(mailComposer !=NULL)
    {
        [self presentModalViewController:mailComposer animated:YES];
    }
     
    [mailComposer release];
}
- (void)dealloc {
  
    [super dealloc];
}
@end
