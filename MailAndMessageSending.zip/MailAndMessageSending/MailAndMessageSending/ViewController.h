//
//  ViewController.h
//  MailAndMessageSending
//
//  Created by mac on 6/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <MobileCoreServices/MobileCoreServices.h>

@interface ViewController : UIViewController<MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate>
{

    
    MFMailComposeViewController *mailComposer;
    MFMessageComposeViewController *messageComposer;

}


- (IBAction)btnSentMessage:(id)sender;

- (IBAction)btnSentMail:(id)sender;


@end
